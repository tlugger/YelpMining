import csv

search_for=('1:00','1/1/2016  12:52:00')

#http://stackoverflow.com/questions/3979077/how-can-i-convert-a-string-to-an-int-in-python
def convertStr(s):
    """Convert string to either int or float."""
    try:
        ret = float(s)
    except ValueError:
        #It's a String.
        ret = s
    return ret

#calculate coverage difference


##Removes empty rows from a fresh data file
with open("pitt2016.csv", 'r') as inp, open('edit.csv', 'w', newline='') as out:
    writer = csv.writer(out)
    #gets rid of SOD
    for row in csv.reader(inp):
        #nodata 
        if row[6] != "SOD" :
            writer.writerow(row)

##Removes rows with undesireable times
with open("edit.csv", 'r') as inp, open('dates.csv', 'w', newline='') as out:
    writer = csv.writer(out)
    #for dates
    for row in csv.reader(inp):
        #taks out 11PM-4:59AM
        if ' 0:' not in row[5] and ' 1:' not in row[5] and ' 2:' not in row[5] and ' 3:' not in row[5] and ' 4:' not in row[5] and ' 23:' not in row[5] and ' 24:' not in row[5]:
            writer.writerow(row)

##Add a new column for calculations using PANDAS
##Code from: http://stackoverflow.com/questions/36882130/how-to-append-a-new-column-to-a-csv-file-using-python


#import csv
#with open("edit.csv", 'r') as inp, open('dates.csv', 'w', newline='') as out:
#   writer = csv.writer(out, lineterminator='\n')
#    for row in csv.reader(inp):
#        writer.writerow([convertStr(row[3])+convertStr(row[4])])







        

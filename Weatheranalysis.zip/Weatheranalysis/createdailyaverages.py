import csv
import pandas as pd

df = pd.read_csv("avgthis.csv")
dailyavgweather=df.groupby('DATE')['DAILYSunset'].mean()
dailyavgweather.to_csv('avgweatherfilled.csv', sep=',')

import csv
import pandas as pd


#http://stackoverflow.com/questions/3979077/how-can-i-convert-a-string-to-an-int-in-python
def convertStr(s):
    """Convert string to either int or float."""
    try:
        ret = float(s)
    except ValueError:
        #It's a String.
        ret = s
    return ret

#calculate coverage difference
##Removes empty rows from a fresh data file
with open("pitt2016.csv", 'r') as inp, open('edit.csv', 'w', newline='') as out:
    writer = csv.writer(out)
    #gets rid of SOD
    for row in csv.reader(inp):
        #nodata 
        if row[6] != "SOD" :
            writer.writerow(row)

##Removes rows with undesireable times
with open("edit.csv", 'r') as inp, open('dates.csv', 'w', newline='') as out:
    writer = csv.writer(out)
    #for dates
    for row in csv.reader(inp):
        #taks out 11PM-4:59AM
        if ' 0:' not in row[5] and ' 1:' not in row[5] and ' 2:' not in row[5] and ' 3:' not in row[5] and ' 4:' not in row[5] and ' 23:' not in row[5] and ' 24:' not in row[5]:
            writer.writerow(row)


##fills in nans with appropriate values
df = pd.read_csv("data.csv")
df['HOURLYSKYCONDITIONS'].fillna(5,inplace=True)
df['HOURLYPRESENTWEATHERTYPE'].fillna(0,inplace=True)


##writes new row with hourly weather rating
with open("edit.csv", 'r') as inp, open('dates.csv', 'w', newline='') as out:
   writer = csv.writer(out, lineterminator='\n')
   int tmp=0
    for row in csv.reader(inp):
        ##needs implementation still refer to LCD_documentation for weather types vs data representation
        ##here need to convert HOURLYSKYCONDITIONS and HOURLYPRESENTWEATHERTYPE
        ##to a value representing what we think is the "average weather rating"
            writer.writerow(tmp)



##this will make a daily average for weather and add each daily
##daily average weather value to the stars dataframe that has daily average stars            
##group by
stars=pd.read_csv('stars.csv')
dailyavgweather=df.groupby('DATE')['AVGWEATHER'].mean()
stars["avg_weather"] = dailyavgweather


        
